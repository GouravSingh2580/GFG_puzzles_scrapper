本工程仅供参考学习使用。切勿广泛传播或用于非法用途，请勿使用此攻击源网站。

## QuickStart

首先需要电脑上有 node 环境. 如果没有请安装 https://nodejs.org/en/


## 初始化

```bash
git clone https://github.com/Qquanwei/a-webtoon-spider

cd a-webtoon-spider

npm install
```

## 下载漫画

```bash
node index.js
```


## 如果漫画有更新，更新漫画

```bash
node index.js
```


## 查看漫画

由于下载下来都是连续的图片，我没有找到很好的阅读软件，所以开了一个坑，目前基本能用。

https://github.com/Qquanwei/electron-webtoon
